#-*-coding:utf-8-*-

import unittest
import os

from connector.LookerConn import *

import warnings

class TestSetsdk(unittest.TestCase):
    """
    Test testcase running
    """
    lookid_initiative= 406

    def test_init(self):
        warnings.filterwarnings(action="ignore", message="unclosed", category=ResourceWarning)
        ini_path = 'connector\looker.ini'
        looker = None
        looker = LookerConn(ini_path)        
        self.assertIsNotNone(looker)
        #self.assertTrue(1)
        
    def test_basic(self):
        warnings.filterwarnings(action="ignore", message="unclosed", category=ResourceWarning)
        ini_path = 'connector\looker.ini'
        looker = None
        looker = LookerConn(ini_path)        
        look = looker.get_look(self.lookid_initiative)
        self.assertIsNotNone(look)
    
class TestFillter(unittest.TestCase):
    """
    Test LookerConn class
    """
    lookid_all_issue = 375
    lookid_all_issue_resolve_date = 463
    lookid_initiative= 406
    lookid_Epic = 402
    
    def test_runlook_with_filter(self):
        warnings.filterwarnings(action="ignore", message="unclosed", category=ResourceWarning)
        ini_path = 'connector\looker.ini'
        looker = None
        looker = LookerConn(ini_path)
        
        rt = looker.run_look(self.lookid_Epic)
        jsondata = json.loads(rt)
        print('return count : %d' % len(jsondata) )
        
        issue_list= []
        
        for json_item in jsondata:      
            bug_id = json_item["jira_ISSUE_LINK.RELATED_ISSUE_KEY"]        
            issue_list.append(bug_id)

        self.assertIsNotNone(rt)
        
        filters: Dict[str, str] = {}
        filters["jira_issues.created_date"] = "NOT NULL"        
        filters["jira_issues.KEY"] = ','.join(issue_list)
        rt = looker.run_look_with_filter(self.lookid_all_issue, filters)
        self.assertIsNotNone(rt)
        #print(rt)
        #print(type(rt))
        
        jsondata = json.loads(rt)
        #print(jsondata)
        print('return count : %d' % len(jsondata) )
        self.assertTrue( len(issue_list) == len(jsondata) )
        