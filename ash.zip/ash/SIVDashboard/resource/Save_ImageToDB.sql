
/*
CREATE TABLE [dbo].[RiskIcons](
	[IconName] [nvarchar](50) NULL,
	[URL] [nchar](10) NULL,
	[data] [varbinary](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
*/
/*
INSERT INTO [dbo].[RiskIcons] (
 IconName
 ,URL
 ,data
 )
 SELECT 'Risky',Null,BulkColumn
FROM Openrowset(BULK 'C:\ETL\SIVDashboard\resource\red.PNG', Single_Blob) as data;

INSERT INTO [dbo].[RiskIcons] (
 IconName
 ,URL
 ,data
 )
 SELECT 'Stable',Null,BulkColumn
FROM Openrowset(BULK 'C:\ETL\SIVDashboard\resource\green.PNG', Single_Blob) as data;

INSERT INTO [dbo].[RiskIcons] (
 IconName
 ,URL
 ,data
 )
 SELECT 'Warning',Null,BulkColumn
FROM Openrowset(BULK 'C:\ETL\SIVDashboard\resource\yellow.PNG', Single_Blob) as data;

INSERT INTO [dbo].[RiskIcons] (
 IconName
 ,URL
 ,data
 )
 SELECT 'None',Null,BulkColumn
FROM Openrowset(BULK 'C:\ETL\SIVDashboard\resource\gray.PNG', Single_Blob) as data;
*/

SELECT TOP (1000) [IconName]
      ,[URL]
      ,[data]
  FROM [testDB].[dbo].[RiskIcons]