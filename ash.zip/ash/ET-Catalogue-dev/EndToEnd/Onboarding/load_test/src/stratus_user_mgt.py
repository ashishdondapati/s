#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
"""
Stratus User Mgt Service test harnesses
"""
# User Defined Exceptions
from exceptions.stratus_user_mgt_http_error import StratusUserMgtHTTPError
from exceptions.stratus_user_mgt_error import StratusUserMgtError

from copy import deepcopy
from config import _DEFAULT_HEADER, PROXIES, STRATUS_USER_MGT_SERVER_STACKS as SERVER_STACKS
import requests
import json

import warnings
warnings.filterwarnings("ignore")


def read_user_profile(user_access_token, user_id, stack='pie', use_proxy=False):

    headers = None

    resp = None

    try:
        url = '{}/v2/usermgtsvc/users/{}'.format(SERVER_STACKS[stack]['stratus_user_mgt_uri'], user_id)
        # systemTenantResourceId used across all Stratus stacks
        url += '?propertyName=externalIdMap.hpid&systemTenantResourceId=c1a46987-cbd3-45db-b94a-a6544116fc2d'
        url += '&contentFilter=email,givenName,familyName,locale'
        headers = deepcopy(_DEFAULT_HEADER)
        headers.update({'Accept': 'application/json',
                        'Authorization': 'Bearer {}'.format(user_access_token)})
        resp = requests.get(url,
                            verify=False,
                            headers=headers,
                            proxies=PROXIES if use_proxy else None)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusUserMgtHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise StratusUserMgtError(err)
    else:
        user_profile = json.loads(resp.text)
    return user_profile
