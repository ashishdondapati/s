#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
# Test Device Onboarding is run by ADO (Azure DevOps) CI Pipeline
#

# This suite test run the unit tests for 3M Yeti Flex - Decline HP+
import sys
sys.path.append("..")

import pytest

from dcs import create_simulated_gen2_printer
from conftest import get_ado_stack, get_user_token, get_hpid_token

from pytest import fail

from exceptions.ucde_error import UCDEError
from exceptions.ucde_http_error import UCDEHTTPError
from exceptions.dcs_error import DCSError
from exceptions.dcs_http_error import DCSHTTPError

from exceptions.stratus_authz_error import StratusAuthZError
from exceptions.stratus_device_error import StratusDeviceError
from exceptions.stratus_authz_http_error import StratusAuthZHTTPError
from exceptions.stratus_device_http_error import StratusDeviceHTTPError

import stratus_authz
import stratus_device
import ucde

import unittest
import warnings

from tests.test_device_onboarding_3m_yeti_flex_param import Param as param
from tests.test_device_onboarding_3m_yeti_flex_splunk_schema import SplunkSchema as splunk_schema

warnings.filterwarnings("ignore")


# test_<1>__<2>_<3>__<4>
# 1 = E2E test name
# 2 = Unit test number out of total unit tests
# 3 = External System or APIs being tested. Examples (UCDE, Stratus_Authz, Stratus_User_Mgt)
# 4 = Use Case or Function is being tested.


class TestDeviceOnboarding3MYetiFlex(unittest.TestCase):

    def setUp(self):
        try:
            param.stack = get_ado_stack()
            param.user_access_token = get_user_token()
            param.hp_id_token = get_hpid_token()
        except ValueError as e:
            print(e)

    def teardown_class(self):
        print("Splunk Disabled for this branch only")
        #splunk_schema.create_splunk_event(splunk_schema)

    @pytest.mark.timeout(120)
    def test_device_onboarding__01_16_dcs__createPrinter(self):
        try:
            gen2_device = create_simulated_gen2_printer(stack=param.stack, profile=param.profile,
                                                        biz_model=param.biz_model, offer=param.offer)
            base64_encoded_fingerprint = gen2_device['cdmPrinterFingerprint']
            base64_encoded_postcard = gen2_device['claimPostcard']
            model_number = gen2_device['productNumber']
            param.uuid = gen2_device['uuid']
            param.device_id = gen2_device['cloud_id']
            printer = ucde.Printer(base64_encoded_postcard, base64_encoded_fingerprint, param.uuid, model_number)
        except DCSHTTPError as HTTPError:
            splunk_schema.error_type.append('DCSHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except DCSError as Error:
            splunk_schema.error_type.append('DCSError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.printer = printer
            self.assertIsNotNone(param.biz_model)
            self.assertIsNotNone(base64_encoded_postcard)
            self.assertIsNotNone(base64_encoded_fingerprint)
            self.assertIsNotNone(param.uuid)
            self.assertIsNotNone(model_number)
            self.assertIsNotNone(printer)
            splunk_schema.test_names.remove('test_device_onboarding__01_16_dcs__createPrinter')

    @pytest.mark.timeout(120)
    def test_device_onboarding__02_16_stratus_authz__get_service_access_token(self):
        try:
            service_access_token = stratus_authz.get_service_access_token(stack=param.stack)
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.service_access_token = service_access_token
            self.assertIsNotNone(service_access_token)
            splunk_schema.test_names.remove('test_device_onboarding__02_16_stratus_authz__get_service_access_token')

    @pytest.mark.timeout(120)
    def test_device_onboarding__03_16_ucde__fetch_ui_extension_info(self):
        try:
            ui_extension_info = ucde.fetch_ui_extension_info(access_token=param.service_access_token,
                                                             printer=param.printer, use_proxy=True,
                                                             extension_info_id='ucde.device.onboard', stack=param.stack)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(param.service_access_token)
            self.assertIsNotNone(ui_extension_info)
            splunk_schema.test_names.remove('test_device_onboarding__03_16_ucde__fetch_ui_extension_info')

    @pytest.mark.timeout(120)
    def test_device_onboarding__04_16_ucde__fetch_ui_infos(self):
        try:
            ui_info = ucde.fetch_ui_infos(access_token=param.service_access_token, printer=param.printer,
                                          extension_info_id='ucde.device.onboard', stack=param.stack,
                                          use_proxy=True)
            param.session_id = ui_info.get("sessionId")
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(param.service_access_token)
            self.assertIsNotNone(ui_info)
            self.assertIsNotNone(param.session_id)
            splunk_schema.test_names.remove('test_device_onboarding__04_16_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_device_onboarding__05_16_ucde__fetch_ui_infos(self):
        try:
            ui_info = ucde.fetch_ui_infos(access_token=param.service_access_token, printer=param.printer,
                                          extension_info_id='ucde.device.onboard',
                                          ui_info_id='ucde.device.onboard.program',
                                          stack=param.stack, session_id=param.session_id, current_result='Decline',
                                          use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(param.service_access_token)
            self.assertIsNotNone(ui_info)
            splunk_schema.test_names.remove('test_device_onboarding__05_16_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_device_onboarding__06_16_ucde__fetch_ui_infos(self):
        try:
            ui_info = ucde.fetch_ui_infos(access_token=param.service_access_token, printer=param.printer,
                                          extension_info_id='ucde.device.onboard',
                                          ui_info_id='ucde.device.onboard.backup.program',
                                          stack=param.stack, session_id=param.session_id, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(param.service_access_token)
            self.assertIsNotNone(ui_info)
            splunk_schema.test_names.remove('test_device_onboarding__06_16_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_device_onboarding__07_16_stratus_authz__exchange_access_token(self):
        try:
            delegated_token = stratus_authz.exchange_access_token(param.user_access_token, stack=param.stack)
            stratus_authz.verify_token(delegated_token, stack=param.stack)
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.delegated_token = delegated_token
            self.assertIsNotNone(param.user_access_token)
            self.assertIsNotNone(param.delegated_token)
            splunk_schema.test_names.remove('test_device_onboarding__07_16_stratus_authz__exchange_access_token')

    @pytest.mark.timeout(120)
    def test_device_onboarding__08_16_ucde__create_account(self):
        try:
            resp = ucde.create_account(user_access_token=param.delegated_token, hpid_id_token=param.hp_id_token,
                                       stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.account_id = resp['resourceId']
            self.assertIsNotNone(param.account_id)
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(param.hp_id_token)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_device_onboarding__08_16_ucde__create_account')

    @pytest.mark.timeout(120)
    def test_device_onboarding__09_16_ucde__fetch_ui_infos(self):
        try:
            ui_info = ucde.fetch_ui_infos(access_token=param.delegated_token, printer=param.printer,
                                          extension_info_id='ucde.device.onboard',
                                          ui_info_id='ucde.user.onboard.login', use_proxy=True,
                                          stack=param.stack, session_id=param.session_id)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.session_id)
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(ui_info)
            splunk_schema.test_names.remove('test_device_onboarding__09_16_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_device_onboarding__10_16_ucde__fetch_consents(self):
        try:
            consents = ucde.fetch_consents(access_token=param.delegated_token, stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(consents)
            param.consents = consents
            splunk_schema.test_names.remove('test_device_onboarding__10_16_ucde__fetch_consents')

    @pytest.mark.timeout(120)
    def test_device_onboarding__11_16_ucde__patch_consents(self):
        try:
            resp = ucde.patch_consents(consents=param.consents, state='OptedOut', access_token=param.delegated_token,
                                       stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(param.consents)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_device_onboarding__11_16_ucde__patch_consents')

    @pytest.mark.timeout(120)
    def test_device_onboarding__12_16_stratus_authz__exchange_access_token(self):
        try:
            delegated_token_with_elevated_scopes = stratus_authz.exchange_access_token(param.user_access_token,
                                                                                       stack=param.stack)
            stratus_authz.verify_token(delegated_token_with_elevated_scopes, stack=param.stack)
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp.error_description)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.user_access_token)
            self.assertIsNotNone(delegated_token_with_elevated_scopes)
            param.delegated_token_with_elevated_scopes = delegated_token_with_elevated_scopes
            splunk_schema.test_names.remove('test_device_onboarding__12_16_stratus_authz__exchange_access_token')

    @pytest.mark.timeout(120)
    def test_device_onboarding__13_16_ucde__fetch_ui_infos(self):
        try:
            ui_info = ucde.fetch_ui_infos(access_token=param.delegated_token_with_elevated_scopes,
                                          printer=param.printer,
                                          extension_info_id='ucde.device.onboard',
                                          ui_info_id='ucde.user.onboard.consents', use_proxy=True,
                                          stack=param.stack, session_id=param.session_id)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token_with_elevated_scopes)
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(ui_info)
            self.assertIsNotNone(param.session_id)
            splunk_schema.test_names.remove('test_device_onboarding__13_16_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_device_onboarding__14_16_ucde__validate_device(self):
        # call validate device and register device here with delegated_token_with_elevated_scopes
        try:
            resp = ucde.validate_device(access_token=param.delegated_token_with_elevated_scopes,
                                        account_id=param.account_id,
                                        printer=param.printer, stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token_with_elevated_scopes)
            self.assertIsNotNone(param.account_id)
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_device_onboarding__14_16_ucde__validate_device')

    @pytest.mark.timeout(120)
    def test_device_onboarding__15_16_ucde__register_device(self):
        try:
            resp = ucde.register_device(access_token=param.delegated_token_with_elevated_scopes,
                                        account_id=param.account_id,
                                        printer=param.printer, stack=param.stack,
                                        selected_biz_model=param.biz_model, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token_with_elevated_scopes)
            self.assertIsNotNone(param.account_id)
            self.assertIsNotNone(param.printer)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_device_onboarding__15_16_ucde__register_device')

    @pytest.mark.timeout(120)
    def test_device_onboarding__16_16_stratus_device__unclaim_device(self):
        try:

            param.ownership_id = stratus_device.fetch_ownership_id(user_access_token=param.user_access_token,
                                                                   device_id=param.device_id, stack=param.stack)

            resp = stratus_device.unclaim_device(user_access_token=param.user_access_token,
                                                 ownership_id=param.ownership_id, stack=param.stack, use_proxy=True)

        except StratusDeviceHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusDeviceHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusDeviceError as Error:
            splunk_schema.error_type.append('StratusDeviceError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.user_access_token)
            self.assertIsNotNone(param.ownership_id)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_device_onboarding__16_16_stratus_device__unclaim_device')
