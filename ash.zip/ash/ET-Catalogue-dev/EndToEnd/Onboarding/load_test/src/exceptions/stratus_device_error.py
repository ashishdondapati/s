class StratusDeviceError(RuntimeError):
    def __init__(self, _error):
        self.error = _error
        self.message = 'Stratus Device Error: \n\t{} '.format(_error)