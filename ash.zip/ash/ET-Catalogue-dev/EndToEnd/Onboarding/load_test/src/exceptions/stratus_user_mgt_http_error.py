import json


class StratusUserMgtHTTPError(RuntimeError):
    def __init__(self, _error, _headers, _data, _resp):
        self.error = _error
        self.resp = _resp
        if 'Authorization' in _headers:
            _headers['Authorization'] = 'Hidden'
        if 'access_token' in _resp:
            _resp['access_token'] = 'Hidden'
        self.message = 'Stratus User Mgt HTTP Error: ' \
                       '\n\t{} ' \
                       '\nStratus User Mgt HTTP Header: ' \
                       '\n\t{}' \
                       '\nStratus User Mgt HTTP Request: ' \
                       '\n\tbody = {}' \
                       '\nStratus User Mgt HTTP Response: ' \
                       '\n\tbody = {}'.format(_error, _headers, json.dumps(_data), _resp.text)
