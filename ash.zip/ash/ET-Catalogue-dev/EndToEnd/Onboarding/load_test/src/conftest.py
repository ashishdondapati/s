#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#

import os


def get_ado_stack():
    ado_stack = os.environ['ADO_STACK']

    if ado_stack is None:
        raise ValueError('ADO STACK Environment Variable is None')

    return ado_stack


def get_ado_files_dir():
    ado_files_dir = os.environ['ADO_WORK_DIR']

    if ado_files_dir is None:
        raise ValueError('Environment Variable Value is None or is Incorrect')
    return ado_files_dir


def get_user_token():
    ado_stack = get_ado_stack()

    ado_files_dir = get_ado_files_dir()

    ows_stratus_ci_user_access_token_sec_file = '{}/{}-ows_stratus_ci_user_access_token_sec_file'.format(
        ado_files_dir, ado_stack)

    if os.path.exists(ows_stratus_ci_user_access_token_sec_file):
        try:
            with open(ows_stratus_ci_user_access_token_sec_file) as user_access_token_sec_file:
                user_access_token = user_access_token_sec_file.read()
        except IOError:
            raise IOError('Secured File ows_stratus_ci_user_access_token_sec_file Not Found')
        else:
            user_access_token_sec_file.close()

    return user_access_token


def get_hpid_token():
    ado_stack = get_ado_stack()

    ado_files_dir = get_ado_files_dir()

    ows_stratus_ci_hp_id_token_sec_file = '{}/{}-ows_stratus_ci_hp_id_token_sec_file'.format(ado_files_dir,
                                                                                             ado_stack)
    if os.path.exists(ows_stratus_ci_hp_id_token_sec_file):
        try:
            with open(ows_stratus_ci_hp_id_token_sec_file) as hp_id_token_sec_file:
                hp_id_token = hp_id_token_sec_file.read()
        except IOError:
            raise IOError('Secured File ows_stratus_ci_hp_id_token_sec_file Not Found')
        else:
            hp_id_token_sec_file.close()

    return hp_id_token
