#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
from config import UCDE_SERVER_STACKS as SERVER_STACKS, PROXIES

# User Defined Exceptions for external applications
from exceptions.ucde_error import UCDEError
from exceptions.ucde_http_error import UCDEHTTPError

import json
import requests
import stratus_authz
import warnings
warnings.filterwarnings("ignore")

API_VERSION = 2

UCDE_BASIC_FUNCTIONALITY_PURPOSE_ID = 'bizops.account.basicfunct.-.ucde.print.npf'

user_onboard_extension_info_id = 'ucde.user.onboard'

ucde_consent_states = {
    'no_selection': 'NoSelection',
    're_opt_in': 'ReOptInRequired',
    'opt_out': 'OptedOut',
    'opt_in': 'OptedIn'
}

default_consent_states = '{},{}'.format(ucde_consent_states['no_selection'], ucde_consent_states['re_opt_in'])


class Printer(object):
    def __init__(self, base64_encoded_postcard, base64_encoded_fingerprint, device_uuid, model_number):
        self.cdmClaimPostcard = str(base64_encoded_postcard, 'utf-8')
        self.cdmPrinterFingerprint = str(base64_encoded_fingerprint, 'utf-8')
        self.productNumber = model_number
        self.uuid = device_uuid


def healthcheck(stack='pie', use_proxy=False):

    resp = None

    try:
        url = '{}/healthcheck'.format(SERVER_STACKS[stack]['ucde_uri'])
        resp = requests.get(url,
                            verify=False,
                            proxies=PROXIES if use_proxy else None)

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, None, None, resp)
    except Exception as err:
        raise UCDEError(err)


def fetch_ui_extension_info(stack='pie', extension_info_id=user_onboard_extension_info_id, printer=None,
                            access_token=None, use_proxy=False):

    headers = None

    data = None

    resp = None

    try:

        url = '{}/v{}/ecosystem/uimgtsvc/uiextensioninfos/{}'.format(SERVER_STACKS[stack]['ucde_uri'], API_VERSION,
                                                                     extension_info_id)

        if access_token is None:
            access_token = stratus_authz.get_service_access_token(stack)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(access_token)}

        data = {}
        if printer:
            data.update({
                "claimPostcard": printer.cdmClaimPostcard,
                "fingerprint": printer.cdmPrinterFingerprint,
                "productNumber": printer.productNumber,
                "uuid": printer.uuid
            })

        resp = requests.post(url, verify=False, data=json.dumps(data), headers=headers,
                             proxies=PROXIES if use_proxy else None)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
        ui_info_list = body['uiExtensionInfo']['uiInfoList']
    return ui_info_list


def fetch_ui_infos(stack='pie', cc='US', lang='en', ui_info_call_type='OOBE',
                   ui_info_id=None, printer=None,extension_info_id=user_onboard_extension_info_id,
                   access_token=None, use_proxy=False, session_id=None, current_result='Ok'):

    headers = None

    data = None

    resp = None

    try:
        url = '{}/v{}/ecosystem/uimgtsvc/uiinfos?country={}&language={}'.format(SERVER_STACKS[stack]['ucde_uri'],
                                                                                API_VERSION, cc, lang)

        if access_token is None:
            access_token = stratus_authz.get_service_access_token(stack)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(access_token)}
        data = {
            "uiExtensionInfoId": extension_info_id,
            "currentUiInfoId": ui_info_id,
            "currentResult": current_result
        }

        if API_VERSION > 1:
            data.update({
                'callType': ui_info_call_type,
                'sessionId': session_id
            })

        if printer:
            data.update({
                'claimPostcard': printer.cdmClaimPostcard,
                'fingerprint': printer.cdmPrinterFingerprint,
                'productNumber': printer.productNumber,
                'uuid': printer.uuid
            })

        resp = requests.post(url,
                             verify=False,
                             data=json.dumps(data),
                             headers=headers,
                             proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
    return body


def create_account(stack='pie', cc='US', lang='en', user_access_token=None, hpid_id_token=None, use_proxy=False):

    headers = None

    data = None

    resp = None

    try:
        url = '{}/v{}/ecosystem/accountmgtsvc/accounts'.format(SERVER_STACKS[stack]['ucde_uri'], API_VERSION)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(user_access_token)}
        data = json.dumps({
            "idToken": hpid_id_token,
            "countrySet": [cc],
            "language": lang
        })
        resp = requests.post(url,
                             verify=False,
                             data=data,
                             headers=headers,
                             proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
    return body


def fetch_consents(stack='pie', cc='US', lang='en', access_token=None, use_proxy=False):

    headers = None

    resp = None

    try:

        url = '{}/v{}/ecosystem/uimgtsvc/consents'.format(SERVER_STACKS[stack]['ucde_uri'], API_VERSION)
        url = '{}?country={}&language={}'.format(url, cc, lang)

        if access_token is None:
            access_token = stratus_authz.get_service_access_token(stack)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(access_token)}

        resp = requests.get(url,
                            verify=False,
                            headers=headers,
                            proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
    return body


def patch_consents(stack='pie', consents=None, state='OptedIn', access_token=None, use_proxy=False):

    headers = None

    data = None

    resp = None

    try:
        url = '{}/v{}/ecosystem/uimgtsvc/consents'.format(SERVER_STACKS[stack]['ucde_uri'], API_VERSION)

        if access_token is None:
            access_token = stratus_authz.get_service_access_token(stack)

        data = {'consentStateChangeRequestMap': {}}
        for consent in consents['consents']:
            # state can be 'OptedIn' or 'OptedOut'
            if consent['purposeId'] != UCDE_BASIC_FUNCTIONALITY_PURPOSE_ID:
                continue
            data['consentStateChangeRequestMap'][consent['resourceId']] = {'state': state}

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(access_token)}

        resp = requests.patch(url,
                              verify=False,
                              data=json.dumps(data),
                              headers=headers,
                              proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)

    return body


def check_user_account(user_access_token, account_id=None, stack='pie', use_proxy=False):

    headers = None

    resp = None

    try:
        url = '{}/v2/ecosystem/accountmgtsvc/accounts'.format(SERVER_STACKS[stack]['ucde_uri'], API_VERSION)
        if account_id:
            url = '{}/{}'.format(url, account_id)
        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(user_access_token)}
        resp = requests.get(url,
                            verify=False,
                            headers=headers,
                            proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
    return body


def check_user_consents(user_access_token, stack='pie', cc='US', lang='en', state='OptedIn', use_proxy=False):

    headers = None

    resp = None

    try:
        url = '{}/v{}/ecosystem/uimgtsvc/consents'.format(SERVER_STACKS[stack]['ucde_uri'], API_VERSION)
        url = '{}?country={}&language={}&state={}'.format(url, cc, lang, state)
        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(user_access_token)}
        resp = requests.get(url,
                            verify=False,
                            headers=headers,
                            proxies=PROXIES if use_proxy else None)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
    return body


def validate_device(stack='pie', account_id=None, printer=None, access_token=None, use_proxy=False):

    headers = None

    data = None

    resp = None

    try:
        url = '{}/v{}/ecosystem/accountmgtsvc/accounts/{}/devices/validate'.format(SERVER_STACKS[stack]['ucde_uri'],
                                                                                   API_VERSION, account_id)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(access_token)}
        data = {
            'claimPostcard': printer.cdmClaimPostcard,
            'fingerprint': printer.cdmPrinterFingerprint,
            'productNumber': printer.productNumber,
            'uuid': printer.uuid
        }

        resp = requests.post(url,
                             verify=False,
                             data=json.dumps(data),
                             headers=headers,
                             proxies=PROXIES if use_proxy else None)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, data, headers, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)
    return body


def register_device(stack='pie', account_id=None, printer=None, access_token=None, use_proxy=False,
                    selected_biz_model='Flex'):

    headers = None

    data = None

    resp = None

    try:
        url = '{}/v{}/ecosystem/accountmgtsvc/accounts/{}/devices'.format(SERVER_STACKS[stack]['ucde_uri'],
                                                                          API_VERSION, account_id)

        headers = {'Content-Type': 'application/json',
                   'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(access_token)}
        data = {
            'claimPostcard': printer.cdmClaimPostcard,
            'fingerprint': printer.cdmPrinterFingerprint,
            'productNumber': printer.productNumber,
            'uuid': printer.uuid
        }
        if API_VERSION > 1:
            data['selectedBizModel'] = selected_biz_model
            data = {"autoClaimRequest": data}

        resp = requests.post(url,
                             verify=False,
                             data=json.dumps(data),
                             headers=headers,
                             proxies=PROXIES if use_proxy else None)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, data, headers, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = json.loads(resp.text)

    return body
