#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
# Test User Onboarding is run by ADO (Azure DevOps) CI Pipeline
#
import json
import unittest

import pytest
import requests

from src import stratus_authz
from src import stratus_user_mgt
from src import ucde
import warnings

from pytest import fail

from src.conftest import get_ado_stack, get_user_token, get_hpid_token

from src.exceptions.stratus_authz_error import StratusAuthZError
from src.exceptions.stratus_authz_http_error import StratusAuthZHTTPError

from src.exceptions.ucde_error import UCDEError
from src.exceptions.ucde_http_error import UCDEHTTPError

from src.exceptions.stratus_user_mgt_error import StratusUserMgtError
from src.exceptions.stratus_user_mgt_http_error import StratusUserMgtHTTPError

from src.tests.ows_stratus_ci.test_user_onboarding_eqt_journey_tests_param import Param as param
from src.tests.ows_stratus_ci.test_user_onboarding_eqt_journey_tests_splunk_schema import SplunkSchema as splunk_schema

warnings.filterwarnings("ignore")


# test_<1>__<2>_<3>__<4>
# 1 = E2E test name
# 2 = Unit test number out of total unit tests
# 3 = External System or APIs being tested. Examples (UCDE, Stratus_Authz, Stratus_User_Mgt)
# 4 = Use Case or Function is being tested.


class TestuserOnboardingEqtJourneyTests(unittest.TestCase):

    def setUp(self):
        try:
            param.stack = get_ado_stack()
            param.user_access_token = get_user_token()
            param.hp_id_token = get_hpid_token()

        except ValueError as e:
            print(e)

    def teardown_class(self):
        splunk_schema.create_splunk_event(splunk_schema)

    @pytest.mark.timeout(120)
    def test_user_onboarding__01_14_stratus_authz__get_service_access_token(self):
        try:
            service_access_token = stratus_authz.get_service_access_token(stack=param.stack)
            param.service_access_token = service_access_token
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(service_access_token)
            splunk_schema.test_names.remove('test_user_onboarding__01_14_stratus_authz__get_service_access_token')

    @pytest.mark.timeout(120)
    def test_user_onboarding__02_14_ucde__fetch_ui_extension_info(self):
        try:
            ui_extension_info = ucde.fetch_ui_extension_info(access_token=param.service_access_token,
                                                             stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(ui_extension_info)
            splunk_schema.test_names.remove('test_user_onboarding__02_14_ucde__fetch_ui_extension_info')

    @pytest.mark.timeout(120)
    def test_user_onboarding__03_14_ucde__fetch_ui_infos(self):
        try:
            ui_info = ucde.fetch_ui_infos(access_token=param.service_access_token, stack=param.stack, use_proxy=True)
            session_id = ui_info.get('sessionId')
            param.session_id = session_id
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.service_access_token)
            self.assertIsNotNone(ui_info)
            self.assertIsNotNone(session_id)
            splunk_schema.test_names.remove('test_user_onboarding__03_14_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_user_onboarding__04_14_stratus_authz__exchange_access_token(self):
        try:
            delegated_token = stratus_authz.exchange_access_token(access_token=param.user_access_token,
                                                                  stack=param.stack)
            stratus_authz.verify_token(delegated_token, stack=param.stack)
            param.delegated_token = delegated_token
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.user_access_token)
            self.assertIsNotNone(delegated_token)
            splunk_schema.test_names.remove('test_user_onboarding__04_14_stratus_authz__exchange_access_token')

    @pytest.mark.timeout(120)
    def test_user_onboarding__05_14_ucde__create_account(self):
        try:
            resp = ucde.create_account(user_access_token=param.delegated_token, hpid_id_token=param.hp_id_token,
                                       stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(param.hp_id_token)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_user_onboarding__05_14_ucde__create_account')

    @pytest.mark.timeout(120)
    def test_user_onboarding__06_14_ucde__fetch_ui_infos(self):
        try:

            ui_info = ucde.fetch_ui_infos(ui_info_id='ucde.user.onboard.login',
                                          access_token=param.delegated_token,
                                          stack=param.stack, session_id=param.session_id,
                                          use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(ui_info)
            self.assertIsNotNone(param.session_id)
            splunk_schema.test_names.remove('test_user_onboarding__06_14_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_user_onboarding__07_14_ucde__fetch_consents(self):
        try:
            consents = ucde.fetch_consents(access_token=param.delegated_token, stack=param.stack,
                                           use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.consents = consents
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(consents)
            splunk_schema.test_names.remove('test_user_onboarding__07_14_ucde__fetch_consents')

    @pytest.mark.timeout(120)
    def test_user_onboarding__08_14_ucde__patch_consents(self):
        try:
            resp = ucde.patch_consents(consents=param.consents, access_token=param.delegated_token,
                                       stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(param.consents)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_user_onboarding__08_14_ucde__patch_consents')

    @pytest.mark.timeout(120)
    def test_user_onboarding__09_14_ucde__fetch_ui_infos(self):
        try:

            ui_info = ucde.fetch_ui_infos(ui_info_id='ucde.user.onboard.consents',
                                          access_token=param.delegated_token, stack=param.stack,
                                          session_id=param.session_id, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.delegated_token)
            self.assertIsNotNone(ui_info)
            self.assertIsNotNone(param.session_id)
            splunk_schema.test_names.remove('test_user_onboarding__09_14_ucde__fetch_ui_infos')

    @pytest.mark.timeout(120)
    def test_user_onboarding__10_14_stratus_authz__exchange_access_token(self):
        try:

            delegated_token_with_elevated_scopes = stratus_authz.exchange_access_token(param.user_access_token,
                                                                                       stack=param.stack)
            stratus_authz.verify_token(delegated_token_with_elevated_scopes, stack=param.stack)
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.delegated_token_with_elevated_scopes = delegated_token_with_elevated_scopes
            self.assertIsNotNone(delegated_token_with_elevated_scopes)
            self.assertIsNotNone(param.user_access_token)
            splunk_schema.test_names.remove('test_user_onboarding__10_14_stratus_authz__exchange_access_token')

    @pytest.mark.timeout(120)
    def test_user_onboarding__11_14_ucde__check_user_account(self):
        try:
            delegated_token_with_elevated_scopes = param.delegated_token_with_elevated_scopes
            resp = ucde.check_user_account(user_access_token=delegated_token_with_elevated_scopes,
                                           stack=param.stack, use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(delegated_token_with_elevated_scopes)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_user_onboarding__11_14_ucde__check_user_account')

    @pytest.mark.timeout(120)
    def test_user_onboarding__12_14_ucde__check_user_consents(self):
        try:
            delegated_token_with_elevated_scopes = param.user_access_token
            resp = ucde.check_user_consents(delegated_token_with_elevated_scopes, stack=param.stack,
                                            use_proxy=True)
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(delegated_token_with_elevated_scopes)
            self.assertIsNotNone(resp)
            splunk_schema.test_names.remove('test_user_onboarding__12_14_ucde__check_user_consents')

    @pytest.mark.timeout(120)
    def test_user_onboarding__13_14_stratus_authz__introspect_token(self):
        try:
            delegated_token_with_elevated_scopes = param.user_access_token
            claim_set = stratus_authz.introspect_token(delegated_token_with_elevated_scopes, stack=param.stack)
            user_id = claim_set['sub']
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            param.user_id = user_id
            self.assertIsNotNone(delegated_token_with_elevated_scopes)
            self.assertIsNotNone(claim_set)
            self.assertIsNotNone(user_id)
            splunk_schema.test_names.remove('test_user_onboarding__13_14_stratus_authz__introspect_token')

    @pytest.mark.timeout(120)
    def test_user_onboarding__14_14_stratus_user_mgt__read_user_profile(self):
        try:
            user_profile = stratus_user_mgt.read_user_profile(user_id=param.user_id,
                                                              user_access_token=param.user_access_token,
                                                              stack=param.stack, use_proxy=True)
        except StratusUserMgtHTTPError as HTTPError:
            self.test_names.error_type.append('StratusUserMgtHTTPError')
            self.test_names.error_message.append(HTTPError.error)
            self.test_names.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusUserMgtError as Error:
            self.test_names.error_type.append('StratusUserMgtError')
            self.test_nameserror_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(param.user_id)
            self.assertIsNotNone(param.user_access_token)
            self.assertIsNotNone(user_profile)
            splunk_schema.test_names.remove('test_user_onboarding__14_14_stratus_user_mgt__read_user_profile')
