#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
#
# Custom Header HTTP 'User-Agent': 'OWS-STRATUS-CI/{}'.format(CodeVersionString)
#

import os

from credentials_ci import CredentialsCI


def _read_code_version():
    filename = '{}/version.txt'.format(os.path.abspath(os.path.dirname(__file__)))
    try:
        with open(filename, 'r')as fh:
            code_version = fh.read()
            return code_version.strip()
    except IOError:
        return 'Code version is not available'


CodeVersionString = _read_code_version()  # sprint release number

_DEFAULT_HEADER = {
    'User-Agent': 'OWS-STRATUS-CI/{}'.format(CodeVersionString)
}

PROXIES = {
    'http': 'http://web-proxy.austin.hpicorp.net:8080',
    'https': 'http://web-proxy.austin.hpicorp.net:8080',
}

PROFILES = {
    'limo': {'modelName': 'HP', 'productNumber': 'A7W94A'},
    'palermo': {'modelName': 'HP Envy 7100 All-in-One Printer', 'productNumber': 'K7R96A'},
    'ellis': {'modelName': 'HP', 'productNumber': 'Y0S19A'},
    'verona': {'modelName': 'HP Envy 5030', 'productNumber': 'M2U75A'},
    'palermolow': {'modelName': 'HP Envy 7100 All-in-One Printer', 'productNumber': 'K7G18A'},
    'palermolowder1': {'modelName': 'HP Envy 7100 All-in-One Printer', 'productNumber': 'K7G93A'},
    'infinitybaseder2': {'modelName': 'HP TANGO', 'productNumber': '2RY54A'},
    'skyreach': {'modelName': 'HP LaserJet MFP', 'productNumber': '6GX01A'},
    'manhattan_yeti': {'modelName': 'HP OfficeJet Pro 9025e All-in-One', 'productNumber': '1G5M0A'},
    'malbec': {'modelName': 'HP OfficeJet Pro 8020 series', 'productNumber': '1KR57A'},
    'manhattanhi': {'modelName': 'HP OfficeJet Pro 9020 series', 'productNumber': '1MR66A'},
}

#credentials_pie = CredentialsCI('pie').get_ows_stratus_ci_credentials()

credentials_stage = CredentialsCI('stage').get_ows_stratus_ci_credentials()

jam_credentials_stage = CredentialsCI('stage').get_jam_ci_credentials()
jam_login_credentials= CredentialsCI('stage').get_jam_login_credentials()

UCDE_SERVER_STACKS = {
    'pie': {
        'ucde_uri': 'https://ucde-pie.tropos-rnd.com',  # accessible only on HP network
    },
    'stage': {
        'ucde_uri': 'https://ucde-stg.tropos-rnd.com',  # accessible only on HP network
    }
}

STRATUS_AUTHZ_SERVER_STACKS = {
    #'pie': {
      #  'stratus_authz_uri': 'https://pie.authz.wpp.api.hp.com',
        #'stratus_authz_id': credentials_pie['authz_client_id'],
       # 'stratus_authz_secret': credentials_pie['authz_client_secret'],
    #},
    'stage': {
        'stratus_authz_uri': 'https://stage.authz.wpp.api.hp.com',
        'stratus_authz_id': credentials_stage['authz_client_id'],
        'stratus_authz_secret': credentials_stage['authz_client_secret']
    }
}

STRATUS_DEVICE_SERVER_STACKS = {
    'pie': {
        'stratus_device_uri': 'https://pie-us.devices.api.avatar.ext.hp.com'
    },
    'stage': {
        'stratus_device_uri': 'https://devices.stage-us1.api.ws-hp.com'
    }
}

STRATUS_USER_MGT_SERVER_STACKS = {
    'pie': {
        'stratus_user_mgt_uri': 'https://stratus-pie.tropos-rnd.com'  # accessible only on HP network
    },
    'stage': {
        'stratus_user_mgt_uri': 'https://stratus-stg.tropos-rnd.com'  # accessible only on HP network
    }
}

DCS_SERVER_STACKS = {
    'pie': {
        'dcs_base_uri': 'https://deviceclaim.pie.avatar.ext.hp.com/dcs-api'
    },
    'stage': {
        'dcs_base_uri': 'https://deviceclaim.stage.avatar.ext.hp.com/dcs-api',
    },
}

URLS = {
    'splunk_uri': 'https://vpce-00daabd0e40e23d89-v1vaan6s.vpce-svc-09ef3836d3c31f339.us-west-2.vpce.amazonaws.com:8088/services/collector'
}


JAM_SERVER_STACKS = {

    'stage': {
        'jam_base_uri': 'https://stage.jamanagement.api.hp.com',
    }
}

UCDE_SERVICES_SERVER_STACKS = {

    'stage': {
        'ucde_services_base_uri': 'https://stage-us1.api.ws-hp.com/ucde/ucde',
    }
}

DEVICE_SERVICES_API= {

    'stage': {
        'device_base_uri': 'https://devices.stage-us1.api.ws-hp.com/devices'
    }
}

JAM_AUTH_SERVER_STACKS = {

    'stage': {
        'jam_authz_uri': 'https://stage.jamanagement.api.hp.com',
        'jam_authz_id': jam_credentials_stage['jam_client_id'],
        'jam_authz_secret': jam_credentials_stage['jam_client_secret'],
        'jam_username': jam_login_credentials['jam_login_id'],
        'jam_password': jam_login_credentials['jam_login_password'],
    }
}