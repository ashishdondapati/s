#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
# Test Device Onboarding is run by ADO (Azure DevOps) CI Pipeline
#

# This suite test run the unit tests for 3M Malbec WFH device
import pytest

from wpp import create_simulated_gen2_printer_wfh
from conftest import get_ado_stack, get_user_token, get_hpid_token

from pytest import fail
from exceptions.ucde_error import UCDEError
from exceptions.ucde_http_error import UCDEHTTPError
from exceptions.dcs_error import DCSError
from exceptions.dcs_http_error import DCSHTTPError
from exceptions.jam_auth_http_error import JAMAuthHTTPError
from exceptions.jam_auth_error import JAMAuthenticationError
from exceptions.stratus_authz_error import StratusAuthZError
from exceptions.stratus_authz_http_error import StratusAuthZHTTPError

from exceptions.io_error import IOError
import stratus_authz
from services import json_service

import jam
import stratus
import unittest
import warnings

from tests.test_device_onboarding_wfh_malbec_param import Param as param
from tests.test_device_onboarding_wfh_malbec_flex_splunk_schema import SplunkSchema as splunk_schema
warnings.filterwarnings("ignore")


# test_<1>__<2>_<3>__<4>
# 1 = E2E test name
# 2 = Unit test number out of total unit tests
# 3 = External System or APIs being tested. Examples (UCDE, Stratus_Authz, Stratus_User_Mgt)
# 4 = Use Case or Function is being tested.


class TestDeviceOnboardingMalbecWFHFlex(unittest.TestCase):

    def setUp(self):
        try:
            param.stack = get_ado_stack()
            param.user_access_token=get_user_token()
            param.hp_id_token = get_hpid_token()
            param.data["user_access_token"] = param.user_access_token
            param.data["stack"] = param.stack
            param.data["modelName"] = param.model_name
            param.data["deviceProductNumber"] = param.derivative_model
            param.data["jamCustomerId"] = param.companyId
            param.data["wppProfileName"] = param.profile

        except ValueError as e:
            print(e)


    def teardown_class(self):
        json_service.create_json_file(param.data)
        splunk_schema.create_splunk_event(splunk_schema)

    @pytest.mark.timeout(240)
    def test_device_onboarding__01_04_wpp__createWFHPrinter(self):

        try:

            gen2_device = create_simulated_gen2_printer_wfh(stack=param.stack, profile=param.profile,
                                                            biz_model=param.biz_model,
                                                            derivativemodel=param.derivative_model)
            base64_encoded_postcard = gen2_device['claimPostcard']
            model_number = gen2_device['product_number']
            param.uuid = gen2_device['uuid']
            param.device_id = gen2_device['cloud_id']
            param.data["cloudId"] = param.device_id
            param.serial_number = gen2_device['serial_number']
            param.data["serialNumber"] = param.serial_number
            param.claim_code = gen2_device['claim_code']
            # printer = ucde.Printer(base64_encoded_postcard, base64_encoded_fingerprint, param.uuid, model_number)
        except DCSHTTPError as HTTPError:
            splunk_schema.error_type.append('DCSHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except DCSError as Error:
            splunk_schema.error_type.append('DCSError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            #param.printer = printer
            self.assertIsNotNone(param.biz_model)
            self.assertIsNotNone(base64_encoded_postcard)
            self.assertIsNotNone(param.uuid)
            self.assertIsNotNone(model_number)
            splunk_schema.test_names.remove('test_device_onboarding__01_04_wpp__createWFHPrinter')

    @pytest.mark.timeout(120)
    def test_device_onboarding__02_04_jam__registerDeviceInJAM(self):
        try:
           guid = jam.add_device_in_jam(serialnumber=param.serial_number, modelname=param.model_name, productnumber=param.derivative_model,
                                          stack=param.stack, company=param.companyId, ipaddress='0.0.0.0',
                                          programname='ws-hp.com/wfh')

        except JAMAuthHTTPError as HTTPError:
            splunk_schema.error_type.append('JAMAuthHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except JAMAuthenticationError as Error:
            splunk_schema.error_type.append('JamAuthenticationError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertIsNotNone(guid)
            param.device_guid = guid
            param.data["deviceGUID"] = guid

            splunk_schema.test_names.remove('test_device_onboarding__02_04_jam__registerDeviceInJAM')

    @pytest.mark.timeout(120)
    def test_device_registration__03_04_claim_device_to_owner(self):
        try:
            claim_set = stratus_authz.introspect_token(param.user_access_token, stack=param.stack)
            user_id = claim_set['sub']
            device_info = stratus.claim_device_to_owner(oAuthtoken=param.user_access_token, printercode=param.claim_code,
                                                        userId=user_id, stack=param.stack, version='1.1')
            param.ownership_id = stratus.get_device_ownership(user_access_token=param.user_access_token,
                                                              cloud_id=param.device_id, stack='stage')
            param.data["ownershipId"] = param.ownership_id
        except StratusAuthZHTTPError as HTTPError:
            splunk_schema.error_type.append('StratusAuthZHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except StratusAuthZError as Error:
            splunk_schema.error_type.append('StratusAuthZError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertTrue(device_info['is_registered'])
            splunk_schema.test_names.remove('test_device_registration__03_04_claim_device_to_owner')

    @pytest.mark.timeout(120)
    def test_device_registration__04_04_add_device_to_wfh(self):
        try:
            device_program_info = stratus.add_device_to_WFHProgram(user_access_token=param.user_access_token , cloud_id=param.device_id,
                                                                    programname='ws-hp.com/wfh', stack='stage')
            param.companyTenantId = device_program_info['companyTenantId']
            param.data["companyTenantId"] = param.companyTenantId
        except UCDEHTTPError as HTTPError:
            splunk_schema.error_type.append('UCDEHTTPError')
            splunk_schema.error_message.append(HTTPError.error)
            splunk_schema.error_http_response_content.append(HTTPError.resp)
            fail(HTTPError.message, False)
        except UCDEError as Error:
            splunk_schema.error_type.append('UCDEError')
            splunk_schema.error_message.append(Error.message)
            fail(Error.message, False)
        else:
            self.assertEquals(device_program_info['state'] , 'Active')
            self.assertEqual(device_program_info['cloudId'], param.device_id)
            self.assertIsNotNone(device_program_info['companyTenantId'])
            splunk_schema.test_names.remove('test_device_registration__04_04_add_device_to_wfh')



