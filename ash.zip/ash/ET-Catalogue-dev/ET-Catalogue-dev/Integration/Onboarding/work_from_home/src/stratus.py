#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#

from copy import deepcopy
from requests.auth import HTTPBasicAuth
import json

# User Defined Exceptions
from exceptions.stratus_authz_http_error import StratusAuthZHTTPError
from exceptions.stratus_authz_error import StratusAuthZError
from exceptions.ucde_error import UCDEError
from exceptions.ucde_http_error import UCDEHTTPError

from config import UCDE_SERVICES_SERVER_STACKS as UCDE_STACKS
from config import  DCS_SERVER_STACKS
from config import DEVICE_SERVICES_API



import requests

import warnings

warnings.filterwarnings("ignore")


# Add device to WFH Program
def add_device_to_WFHProgram(user_access_token, cloud_id,programname,stack='stage'):
    headers = {}
    resp = None
    device_program_info={}
    try:
        url = '{}/v2/ecosystem/programmgtsvc/deviceprograminfos'.format(UCDE_STACKS[stack]['ucde_services_base_uri'])

        headers.update({"Authorization": "Bearer " + user_access_token})
        headers.update({'Accept': '*/*'})
        headers.update({'Accept': '*/*'})
        headers.update({'Content-type': 'application/json', 'User-Agent': 'PostmanRuntime/7.26.8'})
        payload = json.dumps({
            "cloudId": cloud_id,
            "programName": programname
        })
        resp = requests.post(url, headers=headers, data=payload, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = resp.json()
        device_program_info['state'] = body['state']
        device_program_info['cloudId'] = body['cloudId']
        device_program_info['deviceUUID'] = body['deviceUUID']
        device_program_info['companyId'] = body['companyId']
        device_program_info['companyTenantId'] = body['companyTenantId']
    return device_program_info



def claim_device_to_owner(oAuthtoken, printercode, userId, stack='stage', version='1.1'):
    headers = {}
    payload = {}
    resp = None
    device_info={}
    try:
        url = '{}/v2/ownerships'.format(DCS_SERVER_STACKS[stack]['dcs_base_uri'])
        headers.update({"Authorization": "Bearer " + oAuthtoken}) # to be changed to oauth token
        headers.update({'Accept': '*/*'})
        headers.update({'Content-type' :'application/json' ,'User-Agent' : 'PostmanRuntime/7.26.8' })

        payload=json.dumps({
            "version": version,
            "user_id": userId,
            "printer_code": printercode
        })
        resp = requests.post(url, headers=headers, data=payload, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise StratusAuthZError(err)
    else:
        body = resp.json()
        device_info['id'] = body['id']
        device_info['is_registered'] = body['printer_data']['is_registered']
    return device_info

def unregsiter_device_from_WFHProgram(stratus_access_token, serialNumber,productNumber,companyTenantId,stack='stage',):
    headers = {}
    resp = None
    device_program_info={}
    try:
        url = 'https://stage-us1.api.ws-hp.com/ucde/ucde/v2/ecosystem/programmgtsvc/companies/'+str(companyTenantId)+'/participantinfos'
       # url=url.format(UCDE_STACKS[stack]['ucde_services_base_uri'])
        headers.update({"Authorization": "Bearer " + stratus_access_token})
        headers.update({'Accept': '*/*'})
        headers.update({'Content-type': 'application/json', 'User-Agent': 'PostmanRuntime/7.26.8'})
        payload = json.dumps({"deviceInfo":
                                  {"serialNumber": serialNumber,
                                   "productNumber": productNumber}})
        resp = requests.delete(url, headers=headers, data=payload, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise UCDEHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise UCDEError(err)
    else:
        body = resp.json()

    return body

def get_device_ownership(user_access_token, cloud_id,stack='stage'):
    headers = {}
    resp = None
    ownershipId=None
    try:
        url = '{}/v1/ownerships/lookup'.format(DEVICE_SERVICES_API[stack]['device_base_uri'])
        params= {'deviceId' : cloud_id}
        headers.update({"Authorization": "Bearer " + user_access_token})
        headers.update({'Accept': '*/*'})
        headers.update({'Accept': '*/*'})
        headers.update({'Content-type': 'application/json', 'User-Agent': 'PostmanRuntime/7.26.8'})
        resp = requests.get(url, headers=headers, params=params, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise StratusAuthZHTTPError(err)
    else:
        body = resp.json()
        ownershipId = body['ownershipId']


    return ownershipId

def remove_device_ownership(user_access_token, ownershipId,stack='stage'):
    headers = {}
    resp = None
    try:
        url = DEVICE_SERVICES_API[stack]['device_base_uri']+'/v1/ownerships/'+str(ownershipId)
        headers.update({"Authorization": "Bearer " + user_access_token})
        headers.update({'Accept': '*/*'})
        headers.update({'Content-type': 'application/json', 'User-Agent': 'PostmanRuntime/7.26.8'})
        resp = requests.delete(url, headers=headers, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise StratusAuthZHTTPError(err)
    else:
        status_code = resp.status_code
    return status_code
